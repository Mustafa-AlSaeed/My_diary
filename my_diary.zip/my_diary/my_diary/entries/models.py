from django.db import models

# Create your models here.
class Entry(models.Model):
    text = models.TextField()
    date_posted = models.DateTimeField(auto_now_add=True) #automatically puts in the time upon creation of object

    def __str__(self): #because method
        return 'Entry #{}'.format(self.id)

    class Meta:
        verbose_name_plural = 'entries' #since it expects your class to be singular and then adds and an s. this is to avoid that
        
from django.urls import path
from . import views #FROM THE CURRENT MODULE

urlpatterns = [
    path('', views.index, name='home'),
    path('add/', views.add, name='add')
]
